import stylse from "./style.module.css";

export default function Text(props) {
  return (
    <div>
      <div className={stylse.text}>{props.Text}</div>
    </div>
  );
}
